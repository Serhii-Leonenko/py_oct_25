import os
import socket
import gzip

PORT = 8000
TEMPLATES_DIR = "templates"
STATIC_DIR = "static"

RESPONSE_BLOCK = {
    ".html": "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n",
    ".css": "HTTP/1.1 200 OK\r\nContent-Type: text/css\r\n",
}


def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("", PORT))
    server_socket.listen(1)

    while True:
        print("Server waiting...")
        client_socket, addr = server_socket.accept()
        print(f"Accepted connection from {addr}")
        request = client_socket.recv(1024).decode()
        print(f"Received request:\n{request}")
        response_content = generate_response_content(request)
        client_socket.send(response_content)
        client_socket.close()


def should_compress(request):
    headers = request.split("\r\n")

    for header in headers:
        if header.lower().startswith("accept-encoding:"):
            return "gzip" in header.lower()
    return False


def generate_response_content(request):
    file_requested = request.split()[1]

    if file_requested == "/":
        file_requested = "/home.html"

    file_extension = os.path.splitext(file_requested)[1]

    files_dir = ""
    if file_extension == ".html":
        files_dir = TEMPLATES_DIR
    elif file_extension == ".css":
        files_dir = STATIC_DIR

    try:
        with open(f"{files_dir}{file_requested}", "rb") as file:
            file_content = file.read()
    except FileNotFoundError:
        return "HTTP/1.1 404 Not Found\r\n".encode()

    response_headers = RESPONSE_BLOCK.get(file_extension, "HTTP/1.1 404 Not Found\r\n")

    # COMPRESSION
    # if should_compress(request) and file_extension in (".html", ".css"):
    #     compressed_content = gzip.compress(file_content)
    #     response_headers += "Content-Encoding: gzip\r\n"
    #     response_headers += f"Content-Length: {len(compressed_content)}\r\n\r\n"
    #
    #     return response_headers.encode() + compressed_content

    response_headers += f"Content-Length: {len(file_content)}\r\n\r\n"

    return response_headers.encode() + file_content


if __name__ == "__main__":
    main()
