import os
import socket
import gzip
import uuid
from urllib.parse import parse_qs
import time
import hashlib

PORT = 8000
TEMPLATES_DIR = "templates"
STATIC_DIR = "static"
NUMBER_HASH_ITERATIONS = 1000

RESPONSE_BLOCK = {
    ".html": "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n",
    ".css": "HTTP/1.1 200 OK\r\nContent-Type: text/css\r\n",
}

SESSIONS = {}
USERS = {"user": "1000$2e066d4b9fceec8848eb78951eca7abf$3180ceae0741b1b5055f737f98f9b5802ab9d0eaddadabf15dac429aaf0eb72c"}


def hash_password(
    password: str,
    salt: str | None = None,
    iterations: int = NUMBER_HASH_ITERATIONS
) -> tuple[str, str, int]:
    if salt is None:
        salt = os.urandom(16).hex()

    salted = (password + salt).encode('utf-8')
    hashed = salted # salted combination will be hashed

    for _ in range(iterations):
        hashed = hashlib.sha256(hashed).digest()

    return hashed.hex(), salt, iterations


def verify_password(username, password):
    if username not in USERS:
        return False

    iterations, stored_salt, stored_hash = USERS[username].split("$")
    calculated_hash, _, _ = hash_password(password, stored_salt, int(iterations))

    return calculated_hash == stored_hash


def parse_cookies(request):
    cookies = {}
    headers = request.split("\r\n")

    for header in headers:
        if header.lower().startswith("cookie:"):
            cookie_str = header[7:].strip()
            for cookie in cookie_str.split(";"):
                if "=" in cookie:
                    name, value = cookie.strip().split("=", 1)
                    cookies[name] = value
    return cookies


def parse_post_data(request):
    body = request.split("\r\n")[-1]

    return parse_qs(body)


def is_authenticated(request):
    cookies = parse_cookies(request)
    session_id = cookies.get("session_id")

    if not session_id or session_id not in SESSIONS:
        return False

    session = SESSIONS[session_id]
    if session["expires"] < time.time():
        del SESSIONS[session_id]

        return False

    return True


def generate_response_content(request):
    request_line = request.split("\r\n")[0]
    method, path, _ = request_line.split()

    if path == "/register":
        if method == "GET":
            path = "/register.html"
        elif method == "POST":
            post_data = parse_post_data(request)

            username = post_data.get("username", [""])[0]
            password = post_data.get("password", [""])[0]

            if username in USERS:
                return "HTTP/1.1 400 Bad Request\r\n\r\nUser already exists".encode()

            if username and password:
                hashed_password, salt, iterations = hash_password(password)
                USERS[username] = f"{iterations}${salt}${hashed_password}"

                headers = "HTTP/1.1 302 Found\r\n"
                headers += "Location: /login\r\n\r\n"

                return headers.encode()

    if path == "/login":
        if method == "GET":
            path = "/login.html"
        elif method == "POST":
            post_data = parse_post_data(request)
            username = post_data.get("username", [""])[0]
            password = post_data.get("password", [""])[0]

            if verify_password(username, password):
                session_id = str(uuid.uuid4())
                SESSIONS[session_id] = {
                    "username": username,
                    "expires": time.time() + 3600,
                }

                headers = "HTTP/1.1 302 Found\r\n"
                headers += f"Set-Cookie: session_id={session_id}; Path=/; Expires={time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime(time.time() + 3600))}\r\n"
                headers += "Location: /\r\n\r\n"

                return headers.encode()

            return "HTTP/1.1 401 Unauthorized\r\n\r\nAuthentication failed".encode()

    if path == "/logout" and is_authenticated(request):
        cookies = parse_cookies(request)
        session_id = cookies.get("session_id")
        del SESSIONS[session_id]

        headers = "HTTP/1.1 302 Found\r\n"
        headers += "Set-Cookie: session_id=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT\r\n"
        headers += "Location: /login\r\n\r\n"

        return headers.encode()

    if not is_authenticated(request) and "/login" not in path and "/register" not in path:
        headers = "HTTP/1.1 302 Found\r\n"
        headers += "Location: /login\r\n\r\n"

        return headers.encode()

    file_requested = path
    if file_requested == "/":
        file_requested = "/home.html"

    file_extension = os.path.splitext(file_requested)[1]

    files_dir = ""
    if file_extension == ".html":
        files_dir = TEMPLATES_DIR
    elif file_extension == ".css":
        files_dir = STATIC_DIR

    try:
        with open(f"{files_dir}{file_requested}", "rb") as file:
            file_content = file.read()
    except FileNotFoundError:
        return "HTTP/1.1 404 Not Found\r\n".encode()

    response_headers = RESPONSE_BLOCK.get(file_extension, "HTTP/1.1 404 Not Found\r\n")
    response_headers += f"Content-Length: {len(file_content)}\r\n\r\n"

    return response_headers.encode() + file_content


def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("", PORT))
    server_socket.listen(1)

    while True:
        print("Server waiting...")
        client_socket, addr = server_socket.accept()
        print(f"Accepted connection from {addr}")
        request = client_socket.recv(2048).decode()
        print(f"Received request:\n{request}")
        response_content = generate_response_content(request)
        client_socket.send(response_content)
        client_socket.close()


if __name__ == "__main__":
    main()
